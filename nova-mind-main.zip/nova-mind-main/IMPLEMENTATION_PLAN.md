# NOVA MIND AI implementation notes

## Architecture

The project is a dependency-free Node.js HTTP server serving the mobile-first client and preserved Training Lab. Google Gemini is the only AI provider. Gemini chat and image requests are synchronous; video uses Gemini background jobs with job metadata and MP4s in `.nova-data/`. Browser conversations, image history, and sensitivity profiles use the existing local-storage keys and are preserved.

The server checks request origins, limits request volume per client process, validates attachments, and applies a content security policy. It has no account/session layer, server-side chat database, admin roles, or payment integration.

## Current capabilities

- Gemini chat with conversation context and a model list obtained from the configured Gemini API key.
- Coding Studio sends real Gemini requests and never executes generated code.
- Gemini image and video workflows remain separate and use their configured media models.
- Brave Search returns live result excerpts and source links when configured; otherwise the UI reports that search is unavailable.
- Sensitivity tools, theme preference, browser history, and `/training.html` remain available.
- Empty or failed AI responses are errors; no demo or fabricated response is substituted.

Chat responses are currently non-streaming. Gemini video uses provider-defined clip duration and does not claim to compose a longer MP4. Authentication, server-side user data, subscription, payment, credits, and admin features are not implemented.

## Deployment and secrets

Use `.env.example` as a names-only template. Keep real credentials in the local ignored `.env` or a production secret manager. The Render Blueprint requests the Gemini key as a secret and mounts persistent storage for video data. Never commit `.env`, `.envy`, or `.nova-data/`.

For local development, the `.env` Gemini key takes precedence over an inherited shell key. In production, process environment values take precedence. This allows Render to supply its secret without a local file.

## Verification notes

Run JavaScript syntax checks and test chat through the real Gemini API with the configured key. The service checks that model responses contain nonempty text before returning or saving them. Do not replace failed requests with generated-looking placeholder text.
