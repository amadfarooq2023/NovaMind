import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.mjs';
import { chatGemini, verifyGemini } from './providers/gemini.mjs';
import { generateGeminiImage } from './providers/gemini-image.mjs';
import { startVideo, getVideo, listVideos, downloadVideo } from './providers/gemini-video.mjs';
import { allowedRequest, clientOriginAllowed, validateAttachments } from './lib/security.mjs';

const projectRoot = path.dirname(fileURLToPath(import.meta.url));
const publicRoot = path.join(projectRoot, 'public');
const checks = { chat: false, imageModel: false, videoModel: false, videoGeneration: false };
// These models were individually checked with a multi-turn generateContent request.
// generateContent alone is not enough: specialized image, audio, and research models
// also expose it but are not general text chat models.
const VERIFIED_GEMINI_CHAT_MODELS = new Set([
  'gemini-3-flash-preview',
  'gemini-3.1-flash-lite',
  'gemini-3.1-flash-lite-preview',
  'gemini-3.5-flash',
  'gemini-3.5-flash-lite',
  'gemini-flash-lite-latest',
  'gemini-3.8-flash'
]);
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (!clientOriginAllowed(req)) return send(res, 403, { error: 'Request origin rejected.' });
  if (req.method === 'GET' && url.pathname === '/api/health') return send(res, 200, { ok: true, service: 'Nova Mind', provider: 'Google Gemini' });
  if (req.method === 'GET' && url.pathname === '/api/status') return send(res, 200, status());
  if (req.method === 'GET' && url.pathname === '/api/models') return await serveGeminiModels(res);
  if (req.method === 'POST' && url.pathname === '/api/search') {
    if (!allowedRequest(req)) return send(res, 429, { error: 'Too many requests. Wait one minute and try again.' });
    try { return await handleSearch(res, await readBody(req, 16_000)); }
    catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
  }
  if (req.method === 'GET' && url.pathname === '/api/videos') return send(res, 200, { jobs: await listVideos() });
  if (req.method === 'GET' && url.pathname.startsWith('/api/videos/')) {
    const parts = url.pathname.split('/').filter(Boolean);
    if (parts.length === 4 && parts[3] === 'download') return await serveVideo(req, res, parts[2]);
    if (parts.length === 3) {
      try {
        const job = await getVideo(parts[2]);
        if (job?.status === 'succeeded') checks.videoGeneration = true;
        return job ? send(res, 200, job) : send(res, 404, { error: 'Video job not found in saved job history.' });
      } catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
    }
  }
  if (req.method === 'GET' && ['/', '/index.html', '/training.html'].includes(url.pathname)) {
    const name = url.pathname === '/training.html' ? 'training.html' : 'index.html';
    try { return send(res, 200, await readFile(path.join(publicRoot, name), 'utf8'), 'text/html; charset=utf-8'); }
    catch { return send(res, 500, 'Application page missing.', 'text/plain; charset=utf-8'); }
  }
  if (req.method !== 'POST' || !url.pathname.startsWith('/api/')) return send(res, 404, { error: 'Not found.' });
  if (!allowedRequest(req)) return send(res, 429, { error: 'Too many requests. Wait one minute and try again.' });
  try {
    const body = await readBody(req, 20 * 1024 * 1024);
    if (url.pathname === '/api/verify') {
      if (body.provider !== undefined && body.provider !== 'gemini') return send(res, 400, { error: 'Only Google Gemini is supported.' });
      return await verifyGeminiFeature(res, body.feature);
    }
    if (url.pathname === '/api/chat') return await handleChat(res, body);
    if (url.pathname === '/api/images') return await handleImage(res, body);
    if (url.pathname === '/api/videos') return await handleVideo(res, body);
    return send(res, 404, { error: 'Not found.' });
  } catch (error) {
    const statusCode = Number(error?.status) || 500;
    return send(res, statusCode >= 400 && statusCode < 600 ? statusCode : 500, { error: statusCode === 500 ? safeError(error) : safeError(error) });
  }
});

function send(res, statusCode, body, type = 'application/json; charset=utf-8') {
  res.writeHead(statusCode, {
    'content-type': type,
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'cache-control': 'no-store',
    'content-security-policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; frame-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'self'"
  });
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}

function safeError(error) {
  return String(error?.message || 'The request could not be completed.')
    .replace(/AIza[\w-]{20,}|sk-[A-Za-z0-9_-]{12,}/g, '[redacted]')
    .slice(0, 1800);
}

function status() {
  return {
    provider: 'Google Gemini',
    search: { configured: Boolean(config.searchKey), provider: config.searchProvider },
    gemini: {
      configured: Boolean(config.geminiKey),
      keySource: config.geminiKeySource,
      chat: { model: config.geminiModel, verified: checks.chat },
      image: { model: config.geminiImageModel, modelAvailable: checks.imageModel, verified: checks.imageModel },
      video: { model: config.geminiVideoModel, modelAvailable: checks.videoModel, generationVerified: checks.videoGeneration, durationRangeSeconds: '3-10' }
    }
  };
}

async function checkModel(model, requiredMethod) {
  if (!config.geminiKey) throw Object.assign(new Error('GEMINI_API_KEY is missing. Add it to backend .env and restart the server.'), { status: 503 });
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}`, {
    headers: { 'x-goog-api-key': config.geminiKey }, signal: AbortSignal.timeout(20_000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.error?.message || `Google Gemini returned HTTP ${response.status}.`), { status: response.status === 401 ? 401 : response.status === 429 ? 429 : response.status === 404 ? 404 : 502 });
  const actual = data.name?.replace(/^models\//, '');
  if (actual !== model) throw Object.assign(new Error(`Gemini returned unexpected model metadata for ${model}.`), { status: 502 });
  if (requiredMethod && !data.supportedGenerationMethods?.includes(requiredMethod)) {
    throw Object.assign(new Error(`Gemini model ${model} does not support ${requiredMethod}.`), { status: 400 });
  }
  return actual;
}

async function verifyGeminiFeature(res, feature) {
  if (!config.geminiKey) return send(res, 503, { error: 'GEMINI_API_KEY is missing. Add it to backend .env and restart the server.' });
  try {
    if (feature === 'chat') {
      const result = await verifyGemini();
      checks.chat = true;
      return send(res, 200, { ok: true, feature, provider: 'Google Gemini', ...result });
    }
    if (feature === 'image') {
      const model = await checkModel(config.geminiImageModel);
      checks.imageModel = true;
      return send(res, 200, { ok: true, feature, provider: 'Google Gemini', model, generationVerified: false });
    }
    if (feature === 'video') {
      const model = await checkModel(config.geminiVideoModel);
      checks.videoModel = true;
      return send(res, 200, { ok: true, feature, provider: 'Google Gemini', model, generationVerified: checks.videoGeneration });
    }
    return send(res, 400, { error: 'Choose Gemini chat, image, or video model verification.' });
  } catch (error) {
    if (feature === 'chat') checks.chat = false;
    if (feature === 'image') checks.imageModel = false;
    if (feature === 'video') checks.videoModel = false;
    return send(res, Number(error.status) || 502, { error: safeError(error) });
  }
}

async function serveGeminiModels(res) {
  if (!config.geminiKey) return send(res, 503, { error: 'GEMINI_API_KEY is missing. Add it to backend .env and restart the server.' });
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000', {
      headers: { 'x-goog-api-key': config.geminiKey }, signal: AbortSignal.timeout(20_000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw Object.assign(new Error(data.error?.message || `Google Gemini returned HTTP ${response.status}.`), { status: response.status === 401 ? 401 : response.status === 429 ? 429 : response.status === 404 ? 404 : 502 });
    const models = (data.models || [])
      .filter(model => Array.isArray(model.supportedGenerationMethods) && model.supportedGenerationMethods.includes('generateContent'))
      .map(model => String(model.name || '').replace(/^models\//, ''))
      .filter(model => VERIFIED_GEMINI_CHAT_MODELS.has(model))
      .filter(model => /^[A-Za-z0-9._:-]{1,100}$/.test(model));
    return send(res, 200, { models: [...new Set(models)].sort() });
  } catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
}

function validateMessages(raw) {
  if (!Array.isArray(raw) || raw.length < 1 || raw.length > 20) throw Object.assign(new Error('Send between 1 and 20 conversation messages.'), { status: 400 });
  const messages = raw.map(message => {
    if (!message || !['user', 'assistant'].includes(message.role) || typeof message.content !== 'string' || message.content.length > 30_000) throw Object.assign(new Error('Invalid or oversized message.'), { status: 400 });
    const attachments = validateAttachments(message.attachments || []);
    if (!message.content.trim() && !attachments.length) throw Object.assign(new Error('Messages must contain text or an attachment.'), { status: 400 });
    return { role: message.role, content: message.content, attachments };
  });
  if (messages[0].role !== 'user' || messages.at(-1).role !== 'user') {
    throw Object.assign(new Error('Conversation history must start with a user message and end with the current user message.'), { status: 400 });
  }
  return messages;
}

async function handleChat(res, body) {
  const messages = validateMessages(body.messages);
  if (body.provider !== undefined && body.provider !== 'gemini') return send(res, 400, { error: 'Only Google Gemini is supported.' });
  const model = typeof body.model === 'string' && /^[A-Za-z0-9._:-]{1,100}$/.test(body.model) ? body.model : config.geminiModel;
  try {
    let reply;
    try {
      reply = await chatGemini(messages, model);
    } catch (primaryError) {
      // Fallback only for a model-specific daily quota exhaustion, and only to
      // the curated chat set after live metadata confirms generateContent.
      const fallbackModel = 'gemini-3.5-flash-lite';
      if (!primaryError.dailyQuotaExceeded || model === fallbackModel || !VERIFIED_GEMINI_CHAT_MODELS.has(fallbackModel)) {
        throw primaryError;
      }
      try {
        await checkModel(fallbackModel, 'generateContent');
        reply = await chatGemini(messages, fallbackModel);
        reply = { ...reply, requestedModel: model, fallbackFrom: model };
      } catch (fallbackError) {
        const primaryDetail = safeError(primaryError).slice(0, 700);
        const fallbackDetail = safeError(fallbackError).slice(0, 700);
        throw Object.assign(new Error(`${primaryDetail}\nFallback model ${fallbackModel} also failed: ${fallbackDetail}`), { status: Number(fallbackError.status) || 502 });
      }
    }
    if (typeof reply.text !== 'string' || !reply.text.trim()) throw new Error('Gemini returned an empty answer.');
    checks.chat = true;
    return send(res, 200, reply);
  } catch (error) {
    checks.chat = false;
    const code = Number(error.status) || 502;
    console.error(`[gemini:chat] HTTP ${code}: ${safeError(error)}`);
    return send(res, code, { error: safeError(error) });
  }
}

async function handleImage(res, body) {
  if (!config.geminiKey) return send(res, 503, { error: 'GEMINI_API_KEY is missing. Add it to backend .env and restart the server.' });
  if (typeof body.prompt !== 'string' || !body.prompt.trim() || body.prompt.length > 4000) return send(res, 400, { error: 'Enter an image prompt up to 4,000 characters.' });
  const aspect = ({ portrait: '9:16', landscape: '16:9', square: '1:1' })[body.aspect];
  if (!aspect) return send(res, 400, { error: 'Choose portrait, landscape, or square.' });
  let reference;
  if (body.reference) {
    reference = validateAttachments([body.reference])[0];
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(reference.type)) return send(res, 415, { error: 'Gemini image editing accepts JPEG, PNG, or WebP references.' });
  }
  try {
    const result = await generateGeminiImage({ prompt: body.prompt.trim(), aspect, image: reference });
    checks.imageModel = true;
    return send(res, 200, { ...result, aspect: body.aspect, verified: true });
  } catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
}

async function handleVideo(res, body) {
  if (!config.geminiKey) return send(res, 503, { error: 'GEMINI_API_KEY is missing. Add it to backend .env and restart the server.' });
  if (typeof body.prompt !== 'string' || !body.prompt.trim() || body.prompt.length > 3000) return send(res, 400, { error: 'Enter a video prompt up to 3,000 characters.' });
  const aspect = body.aspect === 'portrait' ? '9:16' : body.aspect === 'landscape' ? '16:9' : null;
  if (!aspect) return send(res, 400, { error: 'Choose portrait or landscape.' });
  let image;
  if (body.image) {
    image = validateAttachments([body.image])[0];
    if (!['image/jpeg', 'image/png'].includes(image.type)) return send(res, 415, { error: 'Image-to-video accepts JPEG or PNG images.' });
  }
  try {
    if (!checks.videoModel) { await checkModel(config.geminiVideoModel); checks.videoModel = true; }
    const job = await startVideo({ prompt: body.prompt.trim(), aspect, image });
    return send(res, 202, job);
  } catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
}

async function handleSearch(res, body) {
  const query = typeof body.query === 'string' ? body.query.trim() : '';
  if (!query || query.length > 500) return send(res, 400, { error: 'Enter a search query up to 500 characters.' });
  if (!config.searchKey) return send(res, 503, { error: 'Live web search is unavailable. Add SEARCH_API_KEY for the configured Brave Search provider to the backend .env file, then restart.' });
  if (config.searchProvider !== 'brave') return send(res, 503, { error: 'Unsupported SEARCH_PROVIDER. This build currently supports brave.' });
  const params = new URLSearchParams({ q: query, count: '8' });
  const response = await fetch(`https://api.search.brave.com/res/v1/web/search?${params}`, { headers: { 'x-subscription-token': config.searchKey, accept: 'application/json' }, signal: AbortSignal.timeout(20_000) });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw Object.assign(new Error(data.message || `Brave Search returned HTTP ${response.status}.`), { status: response.status === 429 ? 429 : 502 });
  const results = (data.web?.results || []).slice(0, 8).flatMap(item => { try { const url = new URL(item.url); if (url.protocol !== 'https:') return []; return [{ title: String(item.title || '').slice(0, 300), url: url.href, description: String(item.description || '').slice(0, 1000), age: item.age || null }]; } catch { return []; } });
  return send(res, 200, { query, provider: 'Brave Search', results, summary: 'These are live search result excerpts. Open the cited sources to verify details.' });
}

async function serveVideo(req, res, id) {
  try {
    const bytes = await downloadVideo(id);
    if (!bytes) return send(res, 404, { error: 'Video job is not complete or its saved MP4 is unavailable.' });
    const range = req.headers.range?.match(/^bytes=(\d*)-(\d*)$/);
    if (range) {
      const start = range[1] ? Number(range[1]) : 0;
      const end = Math.min(range[2] ? Number(range[2]) : bytes.length - 1, bytes.length - 1);
      if (start > end || start >= bytes.length) return send(res, 416, { error: 'Requested video byte range is invalid.' });
      res.writeHead(206, { 'content-type': 'video/mp4', 'content-length': end - start + 1, 'content-range': `bytes ${start}-${end}/${bytes.length}`, 'accept-ranges': 'bytes', 'content-disposition': 'attachment; filename="nova-mind-video.mp4"', 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' });
      return res.end(bytes.subarray(start, end + 1));
    }
    res.writeHead(200, { 'content-type': 'video/mp4', 'content-length': bytes.length, 'accept-ranges': 'bytes', 'content-disposition': 'attachment; filename="nova-mind-video.mp4"', 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff' });
    return res.end(bytes);
  } catch (error) { return send(res, Number(error.status) || 502, { error: safeError(error) }); }
}

async function readBody(req, max) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > max) throw Object.assign(new Error('Request is too large.'), { status: 413 });
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON request.'), { status: 400 }); }
}

server.listen(config.port, config.host, () => console.log(`Nova Mind listening at http://${config.host}:${config.port}`));
