export function providerError(httpStatus, payload) {
  const info = { label: 'Google Gemini', env: 'GEMINI_API_KEY' };
  const error = payload?.error ?? payload;
  const message = typeof error === 'string' ? error : error?.message || error?.detail || `HTTP ${httpStatus}`;
  const code = String(error?.code || error?.type || error?.status || '').toLowerCase();
  const detail = String(message);
  const status = Number(httpStatus) || 502;

  if (status === 401 || /invalid api key|api key not valid|incorrect api key|unauthorized|authentication failed/i.test(detail)) {
    return Object.assign(new Error(`${info.label} rejected its API key. Check ${info.env} in the backend .env file, then restart the server.`), { status: 401 });
  }
  if (status === 402 || /insufficient[_ ]quota|insufficient balance|no credits remaining|billing.*(inactive|disabled|not enabled)/i.test(`${code} ${detail}`)) {
    return Object.assign(new Error(`${info.label} returned HTTP 402: API credits or billing are unavailable. Check the Google AI billing account, then retry.`), { status: 402 });
  }
  if (status === 503) {
    return Object.assign(new Error(`${info.label} is temporarily unavailable (HTTP 503): ${detail.slice(0, 1200)}`), { status: 503 });
  }
  if (status === 429 || /quota exceeded|rate limit reached/i.test(`${code} ${detail}`)) {
    const quotaFailures = Array.isArray(error?.details)
      ? error.details.filter(item => item?.['@type'] === 'type.googleapis.com/google.rpc.QuotaFailure').flatMap(item => item.violations || [])
      : [];
    const dailyQuotaExceeded = quotaFailures.some(item => /perday/i.test(String(item?.quotaId || '')))
      || /daily quota|per day limit exceeded|requests per day limit exceeded/i.test(detail);
    return Object.assign(new Error(`${info.label} returned HTTP 429: ${detail.slice(0, 1200)}`), { status: 429, dailyQuotaExceeded });
  }
  if (status === 404 || /model.*(not found|does not exist)|unknown model/i.test(detail)) {
    return Object.assign(new Error(`${info.label} does not recognize the selected model. Check the model ID in the chat model field.`), { status: 400 });
  }
  if (status === 400) {
    return Object.assign(new Error(`${info.label} returned HTTP 400: ${detail.slice(0, 1200)}`), { status: 400 });
  }
  return Object.assign(new Error(`${info.label} request failed: ${detail.slice(0, 1200)}`), { status: 502 });
}
