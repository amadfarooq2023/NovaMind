import { mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from '../config.mjs';
import { providerError } from './errors.mjs';

const API = 'https://generativelanguage.googleapis.com/v1beta';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const videoDir = path.join(root, '.nova-data', 'videos');
const indexPath = path.join(root, '.nova-data', 'video-jobs.json');
const jobs = new Map();
let persistChain = Promise.resolve();
const MAX_JOB_AGE = 30 * 60 * 1000;

await mkdir(videoDir, { recursive: true, mode: 0o700 });
try {
  const records = JSON.parse(await readFile(indexPath, 'utf8'));
  for (const record of Array.isArray(records) ? records : []) {
    if (record && /^[a-f0-9-]{36}$/i.test(record.id) && typeof record.operation === 'string') jobs.set(record.id, record);
  }
} catch { /* No saved jobs yet, or the index is not readable. */ }

function redact(value) {
  return String(value || '').replace(/AIza[\w-]{20,}|sk-[A-Za-z0-9_-]{12,}/g, '[redacted]').slice(0, 1200);
}

function errorText(value) {
  if (typeof value === 'string') return redact(value);
  if (value && typeof value === 'object') {
    if (typeof value.message === 'string') return redact(value.message);
    if (typeof value.error === 'string') return redact(value.error);
    try { return redact(JSON.stringify(value)); } catch { /* use generic below */ }
  }
  return 'Gemini video generation failed without a provider error message.';
}

async function persist() {
  const records = [...jobs.values()].map(({ polling, ...record }) => record);
  const tempPath = `${indexPath}.tmp`;
  persistChain = persistChain.then(async () => {
    await writeFile(tempPath, JSON.stringify(records), { mode: 0o600 });
    await rename(tempPath, indexPath);
  });
  await persistChain;
}

async function api(endpoint, options = {}) {
  const response = await fetch(`${API}/${endpoint}`, {
    ...options,
    headers: { 'x-goog-api-key': config.geminiKey, ...(options.headers || {}) },
    signal: AbortSignal.timeout(120_000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw providerError(response.status, data);
  return data;
}

function getOutput(interaction) {
  if (interaction?.output_video?.data || interaction?.output_video?.uri) return { type: 'video', ...interaction.output_video };
  for (const step of interaction?.steps || []) {
    if (step.type !== 'model_output') continue;
    for (const part of step.content || []) if (part.type === 'video' && (part.data || part.uri)) return part;
  }
  return null;
}

async function saveMp4(job, base64) {
  const bytes = Buffer.from(base64, 'base64');
  if (bytes.length < 16 || bytes.toString('ascii', 4, 8) !== 'ftyp') throw new Error('Gemini returned data that is not a valid MP4 file.');
  const fileName = `${job.id}.mp4`;
  const tempPath = path.join(videoDir, `${fileName}.tmp`);
  await writeFile(tempPath, bytes, { mode: 0o600 });
  await rename(tempPath, path.join(videoDir, fileName));
  job.fileName = fileName;
  job.progress = 100;
  job.updated = Date.now();
  await persist();
}

async function retrieveUri(job, uri) {
  const url = new URL(uri);
  if (url.hostname !== 'generativelanguage.googleapis.com' || !url.pathname.startsWith('/v1beta/files/')) throw new Error('Gemini returned an untrusted video download URL.');
  const id = url.pathname.match(/\/files\/([^/:]+)/)?.[1];
  if (!id) throw new Error('Gemini returned a malformed video file URI.');
  const file = await api(`files/${encodeURIComponent(id)}`);
  if (file.state === 'FAILED') throw new Error('Gemini reported that the generated video file failed processing.');
  if (file.state !== 'ACTIVE') return false;
  let downloadUrl = url;
  if (!downloadUrl.pathname.endsWith(':download')) {
    downloadUrl = new URL(`${API}/files/${encodeURIComponent(id)}:download?alt=media`);
  }
  const response = await fetch(downloadUrl, { headers: { 'x-goog-api-key': config.geminiKey }, signal: AbortSignal.timeout(180_000) });
  if (!response.ok) {
    const detail = await response.json().catch(() => ({}));
    throw providerError(response.status, detail);
  }
  const bytes = Buffer.from(await response.arrayBuffer());
  if (bytes.length < 16 || bytes.toString('ascii', 4, 8) !== 'ftyp') throw new Error('Gemini video download did not contain a valid MP4 file.');
  const fileName = `${job.id}.mp4`, target = path.join(videoDir, fileName), temp = `${target}.tmp`;
  await writeFile(temp, bytes, { mode: 0o600 });
  await rename(temp, target);
  job.fileName = fileName;
  job.progress = 100;
  job.updated = Date.now();
  await persist();
  return true;
}

export async function startVideo({ prompt, aspect, image }) {
  const input = [];
  if (image) input.push({ type: 'image', data: image.data, mime_type: image.type });
  input.push({ type: 'text', text: prompt });
  const interaction = await api('interactions', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      model: config.geminiVideoModel,
      input,
      response_format: { type: 'video', aspect_ratio: aspect, delivery: 'uri' },
      background: true,
      store: true
    })
  });
  if (!interaction.id) throw new Error('Gemini did not return a video interaction job ID.');
  const id = crypto.randomUUID();
  const state = interaction.status || 'in_progress';
  const output = getOutput(interaction);
  const job = {
    id,
    operation: interaction.id,
    state,
    phase: state,
    error: state === 'failed' ? errorText(interaction.error) : null,
    outputUri: output?.uri || null,
    created: Date.now(),
    updated: Date.now(),
    aspect,
    progress: typeof interaction.progress === 'number' ? interaction.progress : null,
    fileName: null
  };
  jobs.set(id, job);
  if (output?.data) await saveMp4(job, output.data);
  await persist();
  return publicJob(job);
}

function publicJob(job) {
  const succeeded = Boolean(job.fileName);
  const failed = ['failed', 'cancelled', 'incomplete', 'budget_exceeded', 'timed_out'].includes(job.state);
  return {
    id: job.id,
    providerJobId: job.operation,
    status: succeeded ? 'succeeded' : failed ? 'failed' : 'running',
    phase: job.phase || job.state,
    progress: succeeded ? 100 : Number.isFinite(job.progress) ? job.progress : null,
    videoReady: succeeded,
    model: config.geminiVideoModel,
    aspect: job.aspect,
    created: job.created,
    error: job.error || null
  };
}

export async function getVideo(id) {
  const job = jobs.get(id);
  if (!job) return null;
  if (job.fileName) return publicJob(job);
  if (Date.now() - job.created > MAX_JOB_AGE) {
    job.state = 'timed_out';
    job.phase = 'timed_out';
    job.error = 'Video generation exceeded the 30-minute job timeout.';
    await persist();
    return publicJob(job);
  }
  if (job.polling) return job.polling;
  job.polling = (async () => {
    try {
      if (!['completed', 'failed', 'cancelled', 'incomplete', 'budget_exceeded'].includes(job.state)) {
        const interaction = await api(`interactions/${encodeURIComponent(job.operation)}`);
        job.state = interaction.status || 'in_progress';
        job.phase = job.state;
        if (typeof interaction.progress === 'number') job.progress = Math.max(0, Math.min(99, interaction.progress));
        const output = getOutput(interaction);
        if (output?.uri) job.outputUri = output.uri;
        if (['failed', 'cancelled'].includes(job.state)) job.error = errorText(interaction.error);
        if (job.state === 'incomplete') job.error = errorText(interaction.error) || 'Gemini returned an incomplete video job.';
        await persist();
        if (output?.data) await saveMp4(job, output.data);
      }
      if (job.state === 'completed' && !job.fileName) {
        const output = job.outputUri ? { uri: job.outputUri } : null;
        if (output?.uri) {
          const ready = await retrieveUri(job, output.uri);
          if (!ready) job.phase = 'video_file_processing';
        } else if (!output?.data) {
          job.state = 'failed';
          job.error = 'Gemini marked the job complete but returned no downloadable MP4.';
        }
      }
    } catch (error) {
      job.error = redact(error.message);
      if (job.state === 'completed') job.phase = 'video_download_retry';
      else { job.state = 'failed'; job.phase = 'failed'; }
    } finally {
      job.updated = Date.now();
      await persist();
      job.polling = null;
    }
    return publicJob(job);
  })();
  return job.polling;
}

export async function listVideos() {
  return [...jobs.values()].sort((a, b) => b.created - a.created).slice(0, 50).map(publicJob);
}

export async function downloadVideo(id) {
  const job = jobs.get(id);
  if (!job?.fileName) return null;
  const target = path.join(videoDir, job.fileName);
  try { await stat(target); return await readFile(target); }
  catch { job.fileName = null; job.state = 'failed'; job.error = 'Saved MP4 file is missing from local storage.'; await persist(); return null; }
}
