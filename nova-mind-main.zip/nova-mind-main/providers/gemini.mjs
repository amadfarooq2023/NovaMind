import { config } from '../config.mjs';
import { providerError } from './errors.mjs';

const API = 'https://generativelanguage.googleapis.com/v1beta';
const REQUEST_TIMEOUT_MS = 45_000;
const TRANSIENT_NETWORK_CODES = new Set([
  'ECONNRESET', 'ECONNREFUSED', 'EAI_AGAIN', 'ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT',
  'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_SOCKET'
]);

function isTransientNetworkFailure(error) {
  // AbortSignal.timeout() is used below, so its TimeoutError denotes a request
  // that exceeded our deadline. Fetch TypeErrors are retryable only when their
  // underlying socket/DNS error is known to be transient.
  if (error?.name === 'TimeoutError') return true;
  return error?.name === 'TypeError' && TRANSIENT_NETWORK_CODES.has(error?.cause?.code);
}

async function request(url, options = {}) {
  let response;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      response = await fetch(url, { ...options, headers: { 'x-goog-api-key': config.geminiKey, ...(options.headers || {}) }, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) });
    } catch (error) {
      // Retry a transient network failure once, preserving the existing behavior.
      if (attempt >= 1 || !isTransientNetworkFailure(error)) throw error;
      await new Promise(resolve => setTimeout(resolve, 250));
      continue;
    }
    // Google may return 503 during temporary capacity spikes. Retry with bounded
    // backoff; do not retry 429, which may represent an exhausted daily quota.
    if (response.status === 503 && attempt < 2) {
      const retryAfter = Number(response.headers.get('retry-after'));
      const waitMs = Number.isFinite(retryAfter) && retryAfter > 0
        ? Math.min(retryAfter * 1000, 5000)
        : 500 * (2 ** attempt);
      await new Promise(resolve => setTimeout(resolve, waitMs));
      continue;
    }
    break;
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw providerError(response.status, data);
  return data;
}
export async function verifyGemini() {
  const result = await chatGemini([{ role: 'user', content: 'Reply with OK only.' }]);
  return { model: result.model };
}

function contents(messages) {
  const turns = messages.map(message => {
    const parts = [];
    if (message.content) parts.push({ text: message.content });
    for (const file of message.attachments || []) {
      if (file.type.startsWith('image/') || file.type === 'application/pdf') parts.push({ inlineData: { mimeType: file.type, data: file.data } });
      else parts.push({ text: `\n\n[Attached document: ${file.name}]\n${Buffer.from(file.data, 'base64').toString('utf8')}` });
    }
    return { role: message.role === 'assistant' ? 'model' : 'user', parts };
  });
  // A failed prior turn can leave adjacent user messages in the saved browser history.
  // Gemini expects alternating Content roles, so combine adjacent same-role entries
  // without dropping any text or attachments.
  return turns.reduce((history, turn) => {
    const previous = history.at(-1);
    if (previous?.role === turn.role) previous.parts.push(...turn.parts);
    else history.push(turn);
    return history;
  }, []);
}
export async function chatGemini(messages, model = config.geminiModel) {
  const generationConfig = { maxOutputTokens: 2500 };
  const data = await request(`${API}/models/${encodeURIComponent(model)}:generateContent`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: 'You are Nova Mind, a helpful personal assistant created and developed by Amad Farooq, the founder and owner of NOVA MIND AI. If anyone asks who created you, answer exactly: ‘I was created by Amad Farooq, the founder and owner of NOVA MIND AI.’ Do not claim a different creator. Understand and reply naturally in Urdu, Roman Urdu, Hindi, or English based on the user. Give clear coding and Termux help. Analyze provided images and documents. If asked for an image or video, direct the user to the dedicated studio; do not claim to create media in chat.' }] },
      contents: contents(messages), generationConfig
    })
  });
  const candidate = data.candidates?.[0];
  // Gemini 3 can return internal thought parts alongside the user-facing answer.
  const text = candidate?.content?.parts?.filter(part => typeof part.text === 'string' && !part.thought).map(part => part.text).join('') || '';
  if (!text) {
    const reason = candidate?.finishReason ? ` (finish reason: ${candidate.finishReason})` : '';
    throw new Error(data.promptFeedback?.blockReason ? `Gemini blocked this request (${data.promptFeedback.blockReason}).` : `Gemini returned no user-facing text response${reason}.`);
  }
  return { text, provider: 'Google Gemini', model: data.modelVersion || model };
}
