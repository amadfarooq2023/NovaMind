import { config } from '../config.mjs';
import { providerError } from './errors.mjs';

const API = 'https://generativelanguage.googleapis.com/v1beta';

async function request(payload) {
  const response = await fetch(`${API}/interactions`, {
    method: 'POST',
    headers: { 'x-goog-api-key': config.geminiKey, 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(180_000)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw providerError(response.status, data);
  return data;
}

function imageFrom(interaction) {
  if (interaction?.output_image?.data) return interaction.output_image;
  for (const step of interaction?.steps || []) {
    if (step.type !== 'model_output') continue;
    for (const part of step.content || []) if (part.type === 'image' && part.data) return part;
  }
  return null;
}

export async function generateGeminiImage({ prompt, aspect, image }) {
  const input = [];
  if (image) input.push({ type: 'image', data: image.data, mime_type: image.type });
  input.push({ type: 'text', text: prompt });
  const interaction = await request({
    model: config.geminiImageModel,
    input,
    response_format: { type: 'image', aspect_ratio: aspect, image_size: '1K' },
    store: false
  });
  const generated = imageFrom(interaction);
  if (!generated?.data) {
    if (interaction.status === 'failed') {
      const message = typeof interaction.error === 'string' ? interaction.error : interaction.error?.message;
      throw new Error(message || 'Gemini image generation failed without returning an image.');
    }
    throw new Error('Gemini completed without returning image data.');
  }
  const mime = ['image/png', 'image/jpeg', 'image/webp'].includes(generated.mime_type) ? generated.mime_type : 'image/png';
  return { image: `data:${mime};base64,${generated.data}`, model: config.geminiImageModel, mimeType: mime };
}
