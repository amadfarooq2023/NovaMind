# NOVA MIND AI

NOVA MIND AI was created and developed by Amad Farooq, its founder and owner. If asked who created it, the assistant identifies Amad Farooq. © 2026 Amad Farooq. All Rights Reserved.

NOVA MIND is a dependency-free Node.js app with Google Gemini as its only AI provider. It serves the mobile-friendly assistant, Coding Studio, image and video studios, Brave-powered Fast Information when configured, sensitivity tools, and the Free Fire Training Lab.

## Gemini chat

Chat and Coding Studio call the backend Gemini API. The Gemini model selector is populated from the models available to the configured key and supports models that expose `generateContent`. Chat history remains in the browser under the existing `fury_threads` local-storage key; each request includes the recent conversation context. Responses are non-streaming. Empty or failed provider results are shown as errors and are never replaced with fabricated text.

The Gemini key is read from the backend `.env` during local development. A local `.env` key takes precedence over an inherited shell `GEMINI_API_KEY`, which avoids accidental use of a stale Termux value. In production, process environment variables take precedence; set `GEMINI_API_KEY` in Render. The key is only sent from the server to Google and is never returned by status or model-list endpoints.

## Termux setup

Use Node.js 20 or newer. No npm dependencies are required.

```sh
cd ~/fury-assistant
cp .env.example .env
nano .env
./start.sh
```

Set `GEMINI_API_KEY` in `.env`, save it privately, and restart the server after changing it. Do not add real keys to source, the browser, or Git. Open `http://127.0.0.1:3000` on the device.

`GEMINI_MODEL` selects the default chat model. The model menu is populated from Gemini models available to that key. Image and video models remain separately configured with `GEMINI_IMAGE_MODEL` and `GEMINI_VIDEO_MODEL`. Optional Brave search uses `SEARCH_API_KEY`; search is independent from AI chat.

## Deployment on Render

The root `render.yaml` defines a paid Node web service, production environment, health check, and a persistent disk mounted at `.nova-data` for Gemini video job records and MP4 files. In Render, create a Blueprint from the GitHub repository and provide `GEMINI_API_KEY` and optionally `SEARCH_API_KEY` as secret environment variables. Do not put secrets in `render.yaml` or GitHub. Render supplies `PORT`; the app binds to `0.0.0.0`.

After Render reports the service live, check `/api/health`, `/api/status`, and `/api/models`, then open `/` and `/training.html`. `/api/status` reports whether a credential is configured, not its value. Free Render web services do not support persistent disks; without the paid disk, video job files are lost on restarts or deployments.

Before pushing, confirm private data is ignored:

```sh
git check-ignore -v .env .envy .nova-data/video-jobs.json
git status --short
```

Commit `.env.example`, never `.env` or `.envy`. If a credential was previously pushed, rotate it with the provider; `.gitignore` does not remove old Git history.

## Data and capabilities

Existing chats, generated image history, and sensitivity profiles remain in each browser under their existing local-storage keys. No migration or deletion of browser history is performed. Video job data stays under `.nova-data/`. No account system, server-side chat database, subscription enforcement, checkout, monthly credits, or admin dashboard is implemented. The app has no user authentication, so protect any public URL against untrusted use of your API quota.

Chat does not stream today. Gemini chat, image, and video requests are real provider calls; the UI displays provider errors and does not invent responses. Video duration remains provider-defined and is not represented as a longer composed clip.
