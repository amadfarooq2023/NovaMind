import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const allowedEnv = new Set(['PORT', 'HOST', 'GEMINI_API_KEY', 'GEMINI_MODEL', 'GEMINI_IMAGE_MODEL', 'GEMINI_VIDEO_MODEL', 'SEARCH_API_KEY', 'SEARCH_PROVIDER']);
const processEnvKeys = new Set([...allowedEnv].filter(name => Boolean(process.env[name])));
const fileEnvKeys = new Set();
try {
  const contents = await readFile(path.join(root, '.env'), 'utf8');
  for (const line of contents.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    const value = match ? match[2].replace(/^(['"])(.*)\1$/, '$2') : '';
    const localGeminiKeyWins = match?.[1] === 'GEMINI_API_KEY' && process.env.NODE_ENV !== 'production' && Boolean(value);
    if (match && allowedEnv.has(match[1]) && (!process.env[match[1]] || localGeminiKeyWins)) {
      process.env[match[1]] = value;
      if (process.env[match[1]]) fileEnvKeys.add(match[1]);
    }
  }
} catch { /* .env is optional; production process environment remains supported. */ }

function keySource(name) {
  if (!process.env[name]) return 'missing';
  return fileEnvKeys.has(name) ? '.env' : processEnvKeys.has(name) ? 'process environment' : 'process environment';
}

export const config = Object.freeze({
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || '0.0.0.0',
  geminiKey: process.env.GEMINI_API_KEY || '',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-3.5-flash-lite',
  geminiImageModel: process.env.GEMINI_IMAGE_MODEL || 'gemini-3.1-flash-image',
  geminiVideoModel: process.env.GEMINI_VIDEO_MODEL || 'gemini-omni-1.1-flash',
  geminiKeySource: keySource('GEMINI_API_KEY'),
  searchKey: process.env.SEARCH_API_KEY || '',
  searchProvider: (process.env.SEARCH_PROVIDER || 'brave').toLowerCase()
});
